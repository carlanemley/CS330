///////////////////////////////////////////////////////////////////////////////
// ViewManager.cpp
// ===============
// Manage camera navigation, mouse interaction, movement speed, and projection
// for my complete CS 330 final desktop scene.
//
// ORIGINAL AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// UPDATED BY: Carla Nemley - SNHU Student
// Course: CS 330 - Computer Graphics and Visualization
// Instructor: Ronald Bishop
// Project: CS 330 Final Project - Desktop Scene
// Last Updated: August 12, 2026
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM math header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Declaration of global variables and constants
namespace
{
	// I use these values to define the OpenGL display window.
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	// I use these names when sending matrices to the shader.
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// I use this camera to navigate and view my 3D mug scene.
	Camera* g_pCamera = nullptr;

	// I use these values to calculate mouse movement.
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// I use delta time to keep movement consistent between frames.
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// I use this value to switch between perspective and
	// orthographic projection.
	bool bOrthographicProjection = false;

	// I use these values to prevent one key press from repeatedly
	// changing the projection while the key remains held down.
	bool gPKeyPressed = false;
	bool gOKeyPressed = false;

	/***********************************************************
	 * Mouse_Scroll_Callback()
	 *
	 * I use the mouse wheel to change the speed at which the
	 * camera travels through the scene.
	 ***********************************************************/
	void Mouse_Scroll_Callback(
		GLFWwindow* window,
		double xOffset,
		double yOffset)
	{
		if (g_pCamera == nullptr)
		{
			return;
		}

		// I increase the speed when scrolling up and decrease it
		// when scrolling down.
		g_pCamera->MovementSpeed +=
			static_cast<float>(yOffset);

		// I keep the movement speed within a practical range.
		if (g_pCamera->MovementSpeed < 1.0f)
		{
			g_pCamera->MovementSpeed = 1.0f;
		}
		else if (g_pCamera->MovementSpeed > 20.0f)
		{
			g_pCamera->MovementSpeed = 20.0f;
		}
	}
}

/***********************************************************
 * ViewManager()
 *
 * I use this constructor to initialize the view manager and
 * position the camera high enough to capture the complete desktop
 * scene while still showing the depth of each 3D object.
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();

	// I start from a wider, elevated position so the mug,
	// notebook, pencil, keyboard, and mouse are all visible.
	g_pCamera->Position = glm::vec3(
		0.0f,
		9.0f,
		17.0f);

	// I aim toward the center of the complete desktop arrangement.
	glm::vec3 sceneTarget = glm::vec3(
		0.0f,
		0.8f,
		-0.3f);

	g_pCamera->Front = glm::normalize(
		sceneTarget - g_pCamera->Position);

	// I use the positive Y-axis to keep the camera upright.
	g_pCamera->Up = glm::vec3(
		0.0f,
		1.0f,
		0.0f);

	// I use a slightly wider field of view for the larger final scene.
	g_pCamera->Zoom = 48.0f;

	// I begin with a comfortable camera movement speed.
	g_pCamera->MovementSpeed = 5.0f;
}

/***********************************************************
 * ~ViewManager()
 *
 * I use this destructor to release the camera memory when the
 * application closes.
 ***********************************************************/
ViewManager::~ViewManager()
{
	m_pShaderManager = NULL;
	m_pWindow = NULL;

	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 * CreateDisplayWindow()
 *
 * I use this method to create the OpenGL window and connect
 * the mouse movement and scroll-wheel callbacks.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(
	const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL,
		NULL);

	if (window == NULL)
	{
		std::cout
			<< "Failed to create GLFW window"
			<< std::endl;

		glfwTerminate();
		return NULL;
	}

	glfwMakeContextCurrent(window);

	// I register mouse movement so I can look around the scene.
	glfwSetCursorPosCallback(
		window,
		&ViewManager::Mouse_Position_Callback);

	// I register the mouse wheel so I can adjust travel speed.
	glfwSetScrollCallback(
		window,
		Mouse_Scroll_Callback);

	// I capture the cursor inside the OpenGL window so camera
	// rotation remains continuous.
	glfwSetInputMode(
		window,
		GLFW_CURSOR,
		GLFW_CURSOR_DISABLED);

	// I enable blending for objects that use transparency.
	glEnable(GL_BLEND);

	glBlendFunc(
		GL_SRC_ALPHA,
		GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return window;
}

/***********************************************************
 * Mouse_Position_Callback()
 *
 * I use this callback to rotate the camera when I move the
 * mouse left, right, up, or down.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
	GLFWwindow* window,
	double xMousePos,
	double yMousePos)
{
	// I save the first cursor location so the camera does not
	// jump when the program begins.
	if (gFirstMouse)
	{
		gLastX =
			static_cast<float>(xMousePos);

		gLastY =
			static_cast<float>(yMousePos);

		gFirstMouse = false;
	}

	// I calculate the horizontal and vertical cursor offsets.
	float xOffset =
		static_cast<float>(xMousePos) - gLastX;

	float yOffset =
		gLastY - static_cast<float>(yMousePos);

	// I save the current location for the next mouse event.
	gLastX =
		static_cast<float>(xMousePos);

	gLastY =
		static_cast<float>(yMousePos);

	if (g_pCamera != nullptr)
	{
		// I pass the offsets to the camera to update its direction.
		g_pCamera->ProcessMouseMovement(
			xOffset,
			yOffset);
	}
}

/***********************************************************
 * ProcessKeyboardEvents()
 *
 * I use this method to process camera navigation and projection
 * controls.
 *
 * W/S move forward and backward.
 * A/D move left and right.
 * Q/E move upward and downward.
 * P selects perspective projection.
 * O selects orthographic projection.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// I close the program when I press Escape.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(
			m_pWindow,
			true);
	}

	if (NULL == g_pCamera)
	{
		return;
	}

	// I use W and S for depth movement.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			FORWARD,
			gDeltaTime);
	}

	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			BACKWARD,
			gDeltaTime);
	}

	// I use A and D for horizontal movement.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			LEFT,
			gDeltaTime);
	}

	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			RIGHT,
			gDeltaTime);
	}

	// I calculate vertical movement with delta time so the camera
	// moves smoothly on different computers.
	float verticalDistance =
		g_pCamera->MovementSpeed * gDeltaTime;

	// I use Q to move upward.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->Position += glm::vec3(
			0.0f,
			verticalDistance,
			0.0f);
	}

	// I use E to move downward.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->Position -= glm::vec3(
			0.0f,
			verticalDistance,
			0.0f);
	}

	// I use P to return to a perspective 3D view.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_P) == GLFW_PRESS)
	{
		if (!gPKeyPressed)
		{
			bOrthographicProjection = false;
			gPKeyPressed = true;
		}
	}
	else
	{
		gPKeyPressed = false;
	}

	// I use O to switch to a flat orthographic view.
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_O) == GLFW_PRESS)
	{
		if (!gOKeyPressed)
		{
			bOrthographicProjection = true;
			gOKeyPressed = true;
		}
	}
	else
	{
		gOKeyPressed = false;
	}
}

/***********************************************************
 * PrepareSceneView()
 *
 * I use this method during every frame to process input,
 * calculate the view and projection matrices, and send them
 * to the shader.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// I calculate the amount of time between frames.
	float currentFrame =
		static_cast<float>(glfwGetTime());

	gDeltaTime =
		currentFrame - gLastFrame;

	gLastFrame =
		currentFrame;

	// I process keyboard input before drawing the next frame.
	ProcessKeyboardEvents();

	// I keep the same camera orientation for both projection modes.
	view = g_pCamera->GetViewMatrix();

	if (bOrthographicProjection)
	{
		// I switch only the projection matrix when O is pressed.
		// The larger bounds keep the full final scene in view.
		float aspectRatio =
			static_cast<float>(WINDOW_WIDTH) /
			static_cast<float>(WINDOW_HEIGHT);

		float viewHeight = 8.0f;
		float viewWidth = viewHeight * aspectRatio;

		projection = glm::ortho(
			-viewWidth,
			viewWidth,
			-viewHeight,
			viewHeight,
			0.1f,
			100.0f);
	}
	else
	{
		projection = glm::perspective(
			glm::radians(g_pCamera->Zoom),
			static_cast<GLfloat>(WINDOW_WIDTH) /
			static_cast<GLfloat>(WINDOW_HEIGHT),
			0.1f,
			100.0f);
	}

	if (NULL != m_pShaderManager)
	{
		// I send the selected view matrix to the shader.
		m_pShaderManager->setMat4Value(
			g_ViewName,
			view);

		// I send the selected projection matrix to the shader.
		m_pShaderManager->setMat4Value(
			g_ProjectionName,
			projection);

		// I send the camera position to the shader for specular lighting.
		m_pShaderManager->setVec3Value(
			"viewPosition",
			g_pCamera->Position);
	}
}