///////////////////////////////////////////////////////////////////////////////
// SceneManager.h
// ==============
// Declare the functions and data used to load textures, define materials,
// configure lighting, transform objects, and render my 3D mug scene.
//
// ORIGINAL AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// UPDATED BY: Carla Nemley - SNHU Student
// Course: CS 330 - Computer Graphics and Visualization
// Instructor: Ronald Bishop
// Project: Milestone Five - Applying Lighting
// Last Updated: August 8, 2026
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>
#include <cstdint>

/***********************************************************
 * SceneManager
 *
 * I use this class to prepare and render my 3D scene. It
 * manages textures, materials, lighting, transformations,
 * and the primitive meshes used to build my mug scene.
 ***********************************************************/
class SceneManager
{
public:

	/***********************************************************
	 * TEXTURE_INFO
	 *
	 * I use this structure to associate each OpenGL texture ID
	 * with a descriptive tag that I can reference later.
	 ***********************************************************/
	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	/***********************************************************
	 * OBJECT_MATERIAL
	 *
	 * I use this structure to store the Phong lighting
	 * properties for each material in my scene.
	 ***********************************************************/
	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

	// I use this constructor to connect the scene manager
	// to the active shader manager.
	SceneManager(
		ShaderManager* pShaderManager);

	// I use this destructor to release textures and mesh memory.
	~SceneManager();

private:

	// I use this pointer to communicate with the active shader.
	ShaderManager* m_pShaderManager;

	// I use this object to load and draw primitive 3D meshes.
	ShapeMeshes* m_basicMeshes;

	// I track how many textures have been loaded into memory.
	int m_loadedTextures;

	// I store information for up to 16 textures.
	TEXTURE_INFO m_textureIDs[16];

	// I store the material definitions used by my scene.
	std::vector<OBJECT_MATERIAL> m_objectMaterials;

	/***********************************************************
	 * Texture management methods
	 ***********************************************************/

	 // I load an image and convert it into an OpenGL texture.
	bool CreateGLTexture(
		const char* filename,
		std::string tag);

	// I bind the loaded textures to OpenGL texture slots.
	void BindGLTextures();

	// I release texture resources when the program closes.
	void DestroyGLTextures();

	// I search for the OpenGL texture ID that matches a tag.
	int FindTextureID(
		std::string tag);

	// I search for the texture slot associated with a tag.
	int FindTextureSlot(
		std::string tag);

	// I load the wood, ceramic, and coffee textures for my scene.
	void LoadSceneTextures();

	/***********************************************************
	 * Material and lighting methods
	 ***********************************************************/

	 // I search for a material definition using its tag.
	bool FindMaterial(
		std::string tag,
		OBJECT_MATERIAL& material);

	// I define the lighting properties for the wood, ceramic,
	// and coffee materials used in my scene.
	void DefineObjectMaterials();

	// I configure the main and secondary light sources.
	void SetupSceneLights();

	/***********************************************************
	 * Transformation and shader methods
	 ***********************************************************/

	 // I scale, rotate, and position each primitive mesh.
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// I send a solid RGBA color to the shader when needed.
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// I activate a loaded texture before drawing an object.
	void SetShaderTexture(
		std::string textureTag);

	// I control how many times a texture repeats across a mesh.
	void SetTextureUVScale(
		float u,
		float v);

	// I send the selected material properties to the shader.
	void SetShaderMaterial(
		std::string materialTag);

public:

	/***********************************************************
	 * Student-customized scene methods
	 ***********************************************************/

	 // I load the textures, materials, lights, and meshes
	 // required by my scene.
	void PrepareScene();

	// I transform, texture, light, and draw the objects.
	void RenderScene();
};