﻿///////////////////////////////////////////////////////////////////////////////
// SceneManager.cpp
// =================
// Manage textures, materials, lighting, transformations, and rendering for my
// final 3D desktop scene based on the selected reference photograph.
//
// ORIGINAL AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// UPDATED BY: Carla Nemley - SNHU Student
// Course: CS 330 - Computer Graphics and Visualization
// Instructor: Ronald Bishop
// Project: CS 330 Final Project - Desktop Scene
// Last Updated: August 12, 2026
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <string>

// Declaration of shader uniform names
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 * SceneManager()
 *
 * I use this constructor to store the shader manager and
 * create the ShapeMeshes object used by my scene.
 ***********************************************************/
SceneManager::SceneManager(
	ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// I initialize all available texture slots before loading images.
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "";
		m_textureIDs[i].ID = 0;
	}

	m_loadedTextures = 0;
}

/***********************************************************
 * ~SceneManager()
 *
 * I use this destructor to release the mesh memory when the
 * application closes.
 ***********************************************************/
SceneManager::~SceneManager()
{
	// I release the OpenGL texture resources before deleting the meshes.
	DestroyGLTextures();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 * CreateGLTexture()
 *
 * This starter method loads image data into an OpenGL texture.
 * My Milestone Two model uses solid colors, but I kept the
 * method available for later milestones.
 ***********************************************************/
 /***********************************************************
  * CreateGLTexture()
  *
  * I use this method to load an image, create an OpenGL
  * texture, and store its texture ID with a descriptive tag.
  ***********************************************************/
bool SceneManager::CreateGLTexture(
	const char* filename,
	std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// I flip the image vertically because OpenGL texture
	// coordinates begin at the lower-left corner.
	stbi_set_flip_vertically_on_load(true);

	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// I stop here if stb_image could not load the file.
	if (image == nullptr)
	{
		std::cout
			<< "Could not load image: "
			<< filename
			<< std::endl;

		const char* failureReason =
			stbi_failure_reason();

		if (failureReason != nullptr)
		{
			std::cout
				<< "stb_image reason: "
				<< failureReason
				<< std::endl;
		}

		return false;
	}

	std::cout
		<< "Successfully loaded image: "
		<< filename
		<< ", width: "
		<< width
		<< ", height: "
		<< height
		<< ", channels: "
		<< colorChannels
		<< std::endl;

	// I prevent the texture array from exceeding its capacity.
	if (m_loadedTextures >= 16)
	{
		std::cout
			<< "The maximum number of textures has been reached."
			<< std::endl;

		stbi_image_free(image);
		return false;
	}

	// I create and bind a new OpenGL texture object.
	glGenTextures(
		1,
		&textureID);

	glBindTexture(
		GL_TEXTURE_2D,
		textureID);

	// This is required for images whose row width is not evenly
	// divisible by four, including my generated texture images.
	glPixelStorei(
		GL_UNPACK_ALIGNMENT,
		1);

	// I repeat the image when UV coordinates extend beyond
	// the standard 0-to-1 range.
	glTexParameteri(
		GL_TEXTURE_2D,
		GL_TEXTURE_WRAP_S,
		GL_REPEAT);

	glTexParameteri(
		GL_TEXTURE_2D,
		GL_TEXTURE_WRAP_T,
		GL_REPEAT);

	// I use linear filtering to smooth the texture when it is
	// displayed at different sizes.
	glTexParameteri(
		GL_TEXTURE_2D,
		GL_TEXTURE_MIN_FILTER,
		GL_LINEAR_MIPMAP_LINEAR);

	glTexParameteri(
		GL_TEXTURE_2D,
		GL_TEXTURE_MAG_FILTER,
		GL_LINEAR);

	// I upload RGB image data when the file has three channels.
	if (colorChannels == 3)
	{
		glTexImage2D(
			GL_TEXTURE_2D,
			0,
			GL_RGB8,
			width,
			height,
			0,
			GL_RGB,
			GL_UNSIGNED_BYTE,
			image);
	}
	// I upload RGBA image data when transparency is included.
	else if (colorChannels == 4)
	{
		glTexImage2D(
			GL_TEXTURE_2D,
			0,
			GL_RGBA8,
			width,
			height,
			0,
			GL_RGBA,
			GL_UNSIGNED_BYTE,
			image);
	}
	else
	{
		std::cout
			<< "Unsupported image channel count: "
			<< colorChannels
			<< std::endl;

		stbi_image_free(image);

		glBindTexture(
			GL_TEXTURE_2D,
			0);

		glDeleteTextures(
			1,
			&textureID);

		return false;
	}

	// I generate mipmaps so the texture remains clear when
	// viewed from different distances.
	glGenerateMipmap(
		GL_TEXTURE_2D);

	// I restore the normal alignment value after uploading.
	glPixelStorei(
		GL_UNPACK_ALIGNMENT,
		4);

	// The image data is no longer needed after it is uploaded.
	stbi_image_free(image);

	glBindTexture(
		GL_TEXTURE_2D,
		0);

	// I save the texture ID and its matching tag.
	m_textureIDs[m_loadedTextures].ID =
		textureID;

	m_textureIDs[m_loadedTextures].tag =
		tag;

	m_loadedTextures++;

	return true;
}

/***********************************************************
 * BindGLTextures()
 *
 * This method binds loaded textures to OpenGL texture slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(
			GL_TEXTURE_2D,
			m_textureIDs[i].ID);
	}
}

/***********************************************************
 * DestroyGLTextures()
 *
 * This method releases the OpenGL texture memory.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(
			1,
			&m_textureIDs[i].ID);
	}
}

/***********************************************************
 * FindTextureID()
 *
 * This method searches for the OpenGL ID associated with a
 * texture tag.
 ***********************************************************/
int SceneManager::FindTextureID(
	std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) &&
		(bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureID;
}

/***********************************************************
 * FindTextureSlot()
 *
 * This method searches for the texture slot associated with
 * a texture tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(
	std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) &&
		(bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
		{
			index++;
		}
	}

	return textureSlot;
}

/***********************************************************
 * FindMaterial()
 *
 * This method searches for a stored material using its tag.
 ***********************************************************/
bool SceneManager::FindMaterial(
	std::string tag,
	OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return false;
	}

	int index = 0;
	bool bFound = false;

	while ((index < m_objectMaterials.size()) &&
		(bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor =
				m_objectMaterials[index].ambientColor;
			material.ambientStrength =
				m_objectMaterials[index].ambientStrength;
			material.diffuseColor =
				m_objectMaterials[index].diffuseColor;
			material.specularColor =
				m_objectMaterials[index].specularColor;
			material.shininess =
				m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return bFound;
}

/***********************************************************
 * SetTransformations()
 *
 * I use this method to scale, rotate, and translate each
 * primitive before drawing it.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	scale = glm::scale(scaleXYZ);

	rotationX = glm::rotate(
		glm::radians(XrotationDegrees),
		glm::vec3(1.0f, 0.0f, 0.0f));

	rotationY = glm::rotate(
		glm::radians(YrotationDegrees),
		glm::vec3(0.0f, 1.0f, 0.0f));

	rotationZ = glm::rotate(
		glm::radians(ZrotationDegrees),
		glm::vec3(0.0f, 0.0f, 1.0f));

	translation = glm::translate(positionXYZ);

	// Transformations are applied as scale, rotation, then translation.
	modelView =
		translation *
		rotationX *
		rotationY *
		rotationZ *
		scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ModelName,
			modelView);
	}
}

/***********************************************************
 * SetShaderColor()
 *
 * I use this method when I need to send a solid color to the
 * shader. My Milestone Five objects primarily use textures,
 * so this method no longer redefines the scene lights.
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	glm::vec4 currentColor(
		redColorValue,
		greenColorValue,
		blueColorValue,
		alphaValue);

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			false);

		m_pShaderManager->setVec4Value(
			g_ColorValueName,
			currentColor);
	}
}

/***********************************************************
 * SetShaderTexture()
 *
 * I use this method to activate a loaded texture before
 * drawing a mesh. Lighting remains enabled so the Phong
 * shader can combine the texture with the scene lights.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		int textureSlot =
			FindTextureSlot(textureTag);

		if (textureSlot < 0)
		{
			std::cout
				<< "Texture tag was not found: "
				<< textureTag
				<< std::endl;

			m_pShaderManager->setIntValue(
				g_UseTextureName,
				false);

			return;
		}

		// I enable the texture while leaving lighting active.
		m_pShaderManager->setIntValue(
			g_UseTextureName,
			true);

		m_pShaderManager->setSampler2DValue(
			g_TextureValueName,
			textureSlot);
	}
}

/***********************************************************
 * SetTextureUVScale()
 *
 * This method controls texture repetition across a mesh.
 ***********************************************************/
void SceneManager::SetTextureUVScale(
	float u,
	float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value(
			"UVscale",
			glm::vec2(u, v));
	}
}

/***********************************************************
 * SetShaderMaterial()
 *
 * This method sends stored material values to the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = FindMaterial(
			materialTag,
			material);

		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value(
				"material.ambientColor",
				material.ambientColor);

			m_pShaderManager->setFloatValue(
				"material.ambientStrength",
				material.ambientStrength);

			m_pShaderManager->setVec3Value(
				"material.diffuseColor",
				material.diffuseColor);

			m_pShaderManager->setVec3Value(
				"material.specularColor",
				material.specularColor);

			m_pShaderManager->setFloatValue(
				"material.shininess",
				material.shininess);
		}
	}
}

/***********************************************************
 * DefineObjectMaterials()
 *
 * I define a small group of reusable materials for the objects
 * in my final desktop scene. I keep the values moderate because
 * the course shader combines contributions from multiple lights.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	m_objectMaterials.clear();

	// I use a soft matte material for the white desktop.
	OBJECT_MATERIAL deskMaterial;
	deskMaterial.ambientColor = glm::vec3(0.14f, 0.14f, 0.14f);
	deskMaterial.ambientStrength = 0.10f;
	deskMaterial.diffuseColor = glm::vec3(0.28f, 0.28f, 0.27f);
	deskMaterial.specularColor = glm::vec3(0.025f);
	deskMaterial.shininess = 1.0f;
	deskMaterial.tag = "desk";
	m_objectMaterials.push_back(deskMaterial);

	// I keep the ceramic slightly reflective so the mug receives
	// a small highlight without creating a harsh hotspot.
	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.ambientColor = glm::vec3(0.12f, 0.11f, 0.10f);
	ceramicMaterial.ambientStrength = 0.11f;
	ceramicMaterial.diffuseColor = glm::vec3(0.26f, 0.24f, 0.21f);
	ceramicMaterial.specularColor = glm::vec3(0.070f, 0.068f, 0.060f);
	ceramicMaterial.shininess = 2.5f;
	ceramicMaterial.tag = "ceramic";
	m_objectMaterials.push_back(ceramicMaterial);

	// I give the coffee enough ambient response to remain visible.
	OBJECT_MATERIAL coffeeMaterial;
	coffeeMaterial.ambientColor = glm::vec3(0.16f, 0.08f, 0.03f);
	coffeeMaterial.ambientStrength = 0.13f;
	coffeeMaterial.diffuseColor = glm::vec3(0.20f, 0.10f, 0.045f);
	coffeeMaterial.specularColor = glm::vec3(0.025f, 0.018f, 0.012f);
	coffeeMaterial.shininess = 1.0f;
	coffeeMaterial.tag = "coffee";
	m_objectMaterials.push_back(coffeeMaterial);

	// I use this material for notebook paper and keyboard plastic.
	OBJECT_MATERIAL lightPlasticMaterial;
	lightPlasticMaterial.ambientColor = glm::vec3(0.14f);
	lightPlasticMaterial.ambientStrength = 0.10f;
	lightPlasticMaterial.diffuseColor = glm::vec3(0.30f, 0.30f, 0.29f);
	lightPlasticMaterial.specularColor = glm::vec3(0.070f, 0.070f, 0.065f);
	lightPlasticMaterial.shininess = 3.0f;
	lightPlasticMaterial.tag = "lightPlastic";
	m_objectMaterials.push_back(lightPlasticMaterial);

	// I use a darker matte material for the pencil and notebook rings.
	OBJECT_MATERIAL darkMaterial;
	darkMaterial.ambientColor = glm::vec3(0.055f);
	darkMaterial.ambientStrength = 0.10f;
	darkMaterial.diffuseColor = glm::vec3(0.08f);
	darkMaterial.specularColor = glm::vec3(0.025f);
	darkMaterial.shininess = 1.0f;
	darkMaterial.tag = "dark";
	m_objectMaterials.push_back(darkMaterial);

	// I use a warm material for the pencil wood and eraser band.
	OBJECT_MATERIAL warmMaterial;
	warmMaterial.ambientColor = glm::vec3(0.16f, 0.10f, 0.04f);
	warmMaterial.ambientStrength = 0.10f;
	warmMaterial.diffuseColor = glm::vec3(0.18f, 0.11f, 0.05f);
	warmMaterial.specularColor = glm::vec3(0.04f, 0.03f, 0.01f);
	warmMaterial.shininess = 1.5f;
	warmMaterial.tag = "warm";
	m_objectMaterials.push_back(warmMaterial);

	// I reuse the wood texture as a subtle textured notebook backing.
	OBJECT_MATERIAL notebookBackingMaterial;
	notebookBackingMaterial.ambientColor = glm::vec3(0.11f, 0.075f, 0.04f);
	notebookBackingMaterial.ambientStrength = 0.10f;
	notebookBackingMaterial.diffuseColor = glm::vec3(0.15f, 0.10f, 0.06f);
	notebookBackingMaterial.specularColor = glm::vec3(0.02f);
	notebookBackingMaterial.shininess = 1.0f;
	notebookBackingMaterial.tag = "notebookBacking";
	m_objectMaterials.push_back(notebookBackingMaterial);
}

/***********************************************************
 * SetupSceneLights()
 *
 * I use all three light slots supported by the professor-provided
 * fragment shader. That shader uses each light's ambient color and
 * the material diffuse response when calculating brightness, so I
 * spread three lights around the scene instead of relying on one
 * intense source. I keep ambient light controlled and allow the
 * diffuse response to create stronger light-to-dark changes across
 * object faces, giving the white objects more visible dimension.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	m_pShaderManager->setBoolValue(
		g_UseLightingName,
		true);

	/***********************************************************
	 * LIGHT 0 - MAIN WARM POINT LIGHT
	 *
	 * I place the main light high and toward the front-right side.
	 * Its warm ambient color brightens the scene without creating
	 * the harsh glare that appeared in an earlier milestone.
	 ***********************************************************/
	m_pShaderManager->setVec3Value(
		"lightSources[0].position",
		glm::vec3(6.0f, 12.0f, 8.0f));

	m_pShaderManager->setVec3Value(
		"lightSources[0].ambientColor",
		glm::vec3(0.045f, 0.040f, 0.032f));

	// These values remain populated for the shader structure even
	// though the provided shader primarily uses material diffuse color.
	m_pShaderManager->setVec3Value(
		"lightSources[0].diffuseColor",
		glm::vec3(0.40f, 0.36f, 0.30f));

	m_pShaderManager->setVec3Value(
		"lightSources[0].specularColor",
		glm::vec3(0.08f, 0.07f, 0.06f));

	m_pShaderManager->setFloatValue(
		"lightSources[0].focalStrength",
		24.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[0].specularIntensity",
		0.022f);

	/***********************************************************
	 * LIGHT 1 - COOL COLORED FILL LIGHT
	 *
	 * I use a subtle blue-tinted fill from the upper-left side.
	 * This satisfies the colored-light requirement and keeps the
	 * left sides of the notebook, keyboard, and mug from becoming
	 * too dark when the camera moves.
	 ***********************************************************/
	m_pShaderManager->setVec3Value(
		"lightSources[1].position",
		glm::vec3(-8.0f, 10.0f, 2.0f));

	m_pShaderManager->setVec3Value(
		"lightSources[1].ambientColor",
		glm::vec3(0.020f, 0.030f, 0.050f));

	m_pShaderManager->setVec3Value(
		"lightSources[1].diffuseColor",
		glm::vec3(0.18f, 0.22f, 0.30f));

	m_pShaderManager->setVec3Value(
		"lightSources[1].specularColor",
		glm::vec3(0.025f, 0.035f, 0.055f));

	m_pShaderManager->setFloatValue(
		"lightSources[1].focalStrength",
		20.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[1].specularIntensity",
		0.008f);

	/***********************************************************
	 * LIGHT 2 - OVERHEAD FILL
	 *
	 * I use the third supported light as a neutral overhead fill.
	 * This is intentionally softer than the main light, but it adds
	 * enough illumination to the broad desktop and the top surfaces
	 * of the keyboard, notebook, mouse, and coffee.
	 ***********************************************************/
	m_pShaderManager->setVec3Value(
		"lightSources[2].position",
		glm::vec3(0.0f, 14.0f, -1.0f));

	m_pShaderManager->setVec3Value(
		"lightSources[2].ambientColor",
		glm::vec3(0.028f, 0.028f, 0.026f));

	m_pShaderManager->setVec3Value(
		"lightSources[2].diffuseColor",
		glm::vec3(0.24f, 0.24f, 0.22f));

	m_pShaderManager->setVec3Value(
		"lightSources[2].specularColor",
		glm::vec3(0.035f));

	m_pShaderManager->setFloatValue(
		"lightSources[2].focalStrength",
		28.0f);

	m_pShaderManager->setFloatValue(
		"lightSources[2].specularIntensity",
		0.010f);
}

/***********************************************************
 * LoadSceneTextures()
 *
 * I use this method to load the three image files used in my
 * scene and associate each image with a descriptive texture tag.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// I load a warm wood texture for the desk surface.
	bReturn = CreateGLTexture(
		"../../Utilities/textures/wood_desk.jpg",
		"woodDesk");

	if (bReturn == false)
	{
		std::cout << "The wood desk texture could not be loaded." << std::endl;
	}

	// I load a lightly speckled ceramic texture for both the mug
	// body and handle so the separate shapes appear cohesive.
	bReturn = CreateGLTexture(
		"../../Utilities/textures/ceramic_mug.jpg",
		"ceramicMug");

	if (bReturn == false)
	{
		std::cout << "The ceramic mug texture could not be loaded." << std::endl;
	}

	// I load a dark coffee texture for the liquid surface.
	bReturn = CreateGLTexture(
		"../../Utilities/textures/coffee.jpg",
		"coffee");

	if (bReturn == false)
	{
		std::cout << "The coffee texture could not be loaded." << std::endl;
	}

	// I bind the loaded textures to OpenGL texture slots after
	// all image data has been prepared.
	BindGLTextures();
}

/***********************************************************
 * PrepareScene()
 *
 * I load the textures, lighting data, and primitive meshes once
 * before the rendering loop begins. My final scene uses seven
 * primitive types, which exceeds the four-type project requirement.
 ***********************************************************/
void SceneManager::PrepareScene()
{
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadSphereMesh();
}

/***********************************************************
 * RenderScene()
 *
 * I recreate the main layout of my reference image using a mug,
 * notebook, pencil, keyboard, mouse, and desktop. The mug remains
 * my complex object because it combines a tapered cylinder,
 * cylinder, and torus.
 ***********************************************************/
void SceneManager::RenderScene()
{
	glm::vec3 scaleXYZ;
	glm::vec3 positionXYZ;

	/***********************************************************
	 * WHITE DESKTOP
	 ***********************************************************/
	scaleXYZ = glm::vec3(12.0f, 1.0f, 10.0f);
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(0.78f, 0.76f, 0.72f, 1.0f);
	SetShaderMaterial("desk");
	m_basicMeshes->DrawPlaneMesh();

	/***********************************************************
	 * COFFEE MUG - LEFT FRONT
	 *
	 * I shift the complete mug toward the left side of the scene
	 * to match its placement in the reference photograph.
	 ***********************************************************/
	const float mugX = -4.0f;
	const float mugZ = 2.0f;

	// Mug body
	scaleXYZ = glm::vec3(1.45f, 2.35f, 1.45f);
	positionXYZ = glm::vec3(mugX, 2.35f, mugZ);

	SetTransformations(
		scaleXYZ,
		180.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetTextureUVScale(2.0f, 1.0f);
	SetShaderTexture("ceramicMug");
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawTaperedCylinderMesh();

	// Coffee surface
	scaleXYZ = glm::vec3(1.08f, 0.030f, 1.08f);
	positionXYZ = glm::vec3(mugX, 2.34f, mugZ);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("coffee");
	SetShaderMaterial("coffee");
	m_basicMeshes->DrawCylinderMesh();

	// Mug handle
	scaleXYZ = glm::vec3(0.64f, 0.78f, 0.25f);
	positionXYZ = glm::vec3(mugX + 1.42f, 1.30f, mugZ);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetTextureUVScale(1.0f, 1.0f);
	SetShaderTexture("ceramicMug");
	SetShaderMaterial("ceramic");
	m_basicMeshes->DrawTorusMesh();

	/***********************************************************
	 * NOTEBOOK - CENTER RIGHT
	 *
	 * I build the notebook from two thin boxes and add small torus
	 * rings along its back edge to suggest spiral binding.
	 ***********************************************************/

	 // Textured backing
	scaleXYZ = glm::vec3(3.15f, 0.10f, 4.10f);
	positionXYZ = glm::vec3(1.25f, 0.12f, 0.55f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		-8.0f,
		0.0f,
		positionXYZ);

	SetTextureUVScale(1.5f, 1.5f);
	SetShaderTexture("woodDesk");
	SetShaderMaterial("notebookBacking");
	m_basicMeshes->DrawBoxMesh();

	// White paper
	scaleXYZ = glm::vec3(2.85f, 0.08f, 3.82f);
	positionXYZ = glm::vec3(1.38f, 0.24f, 0.45f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		-8.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(0.98f, 0.97f, 0.93f, 1.0f);
	SetShaderMaterial("lightPlastic");
	m_basicMeshes->DrawBoxMesh();

	// Spiral rings
	// I keep the rings centered across the notebook's top edge instead
	// of allowing them to extend beyond the paper.
	for (int ring = 0; ring < 8; ring++)
	{
		float ringX = -1.05f + (ring * 0.30f);

		scaleXYZ = glm::vec3(0.11f, 0.16f, 0.050f);
		positionXYZ = glm::vec3(
			1.38f + ringX,
			0.34f,
			-1.48f);

		SetTransformations(
			scaleXYZ,
			0.0f,
			90.0f,
			0.0f,
			positionXYZ);

		SetShaderColor(0.06f, 0.06f, 0.06f, 1.0f);
		SetShaderMaterial("dark");
		m_basicMeshes->DrawTorusMesh();
	}

	/***********************************************************
	 * PENCIL - LOWER CENTER
	 *
	 * I combine a cylinder and cone to make a simple pencil.
	 ***********************************************************/

	 // Pencil body
	scaleXYZ = glm::vec3(0.13f, 2.65f, 0.13f);
	positionXYZ = glm::vec3(-0.85f, 0.18f, 2.65f);

	SetTransformations(
		scaleXYZ,
		90.0f,
		25.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(0.055f, 0.055f, 0.050f, 1.0f);
	SetShaderMaterial("dark");
	m_basicMeshes->DrawCylinderMesh();

	// Wooden sharpened tip
	// I keep the tip on the same centerline as the pencil body.
	scaleXYZ = glm::vec3(0.15f, 0.42f, 0.15f);
	positionXYZ = glm::vec3(-0.85f, 0.18f, 5.30f);

	SetTransformations(
		scaleXYZ,
		90.0f,
		25.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(0.72f, 0.52f, 0.28f, 1.0f);
	SetShaderMaterial("warm");
	m_basicMeshes->DrawConeMesh();

	// Gold-colored eraser band
	// I place the band directly on the opposite end of the pencil.
	scaleXYZ = glm::vec3(0.14f, 0.16f, 0.14f);
	positionXYZ = glm::vec3(-0.85f, 0.18f, 2.42f);

	SetTransformations(
		scaleXYZ,
		90.0f,
		25.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(0.72f, 0.53f, 0.16f, 1.0f);
	SetShaderMaterial("warm");
	m_basicMeshes->DrawCylinderMesh();

	// Pink eraser
	// I place the eraser immediately beyond the gold band so the
	// three pencil pieces read as one connected object.
	scaleXYZ = glm::vec3(0.13f, 0.20f, 0.13f);
	positionXYZ = glm::vec3(-0.85f, 0.18f, 2.24f);

	SetTransformations(
		scaleXYZ,
		90.0f,
		25.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(0.58f, 0.28f, 0.30f, 1.0f);
	SetShaderMaterial("warm");
	m_basicMeshes->DrawCylinderMesh();

	/***********************************************************
	 * KEYBOARD - BACK LEFT
	 *
	 * I build the keyboard from one shallow box and a grid of
	 * smaller boxes. This keeps the model low polygon while making
	 * it immediately recognizable as a keyboard.
	 ***********************************************************/

	 // Keyboard base
	scaleXYZ = glm::vec3(5.30f, 0.22f, 1.80f);
	positionXYZ = glm::vec3(-2.05f, 0.22f, -4.05f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(0.58f, 0.62f, 0.68f, 1.0f);
	SetShaderMaterial("lightPlastic");
	m_basicMeshes->DrawBoxMesh();

	// Keyboard keys
	for (int row = 0; row < 4; row++)
	{
		for (int column = 0; column < 11; column++)
		{
			float keyX = -4.35f + (column * 0.46f);
			float keyZ = -4.62f + (row * 0.38f);

			scaleXYZ = glm::vec3(0.37f, 0.10f, 0.27f);
			positionXYZ = glm::vec3(keyX, 0.40f, keyZ);

			SetTransformations(
				scaleXYZ,
				0.0f,
				0.0f,
				0.0f,
				positionXYZ);

			SetShaderColor(0.78f, 0.82f, 0.88f, 1.0f);
			SetShaderMaterial("lightPlastic");
			m_basicMeshes->DrawBoxMesh();
		}
	}

	// Space bar
	scaleXYZ = glm::vec3(1.70f, 0.10f, 0.27f);
	positionXYZ = glm::vec3(-2.00f, 0.40f, -3.48f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(0.78f, 0.82f, 0.88f, 1.0f);
	SetShaderMaterial("lightPlastic");
	m_basicMeshes->DrawBoxMesh();

	/***********************************************************
	 * COMPUTER MOUSE - BACK RIGHT
	 *
	 * I flatten and stretch a sphere to make a simple rounded mouse.
	 * Placing it near the keyboard makes its purpose clear.
	 ***********************************************************/
	scaleXYZ = glm::vec3(0.78f, 0.38f, 1.08f);
	positionXYZ = glm::vec3(4.30f, 0.40f, -3.70f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		12.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(0.84f, 0.84f, 0.81f, 1.0f);
	SetShaderMaterial("lightPlastic");
	m_basicMeshes->DrawSphereMesh();
}